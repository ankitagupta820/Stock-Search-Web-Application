module.exports.news_token = "3c6ac99a202f43b68ba76bdc1c71fe85"
module.exports.tingoo_token = "33267e3c1022094b94c0643e1382d5ce3b728869"